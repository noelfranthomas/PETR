Fibroids are non-cancerous growths that develop in the muscular wall of the womb (uterus). These growths are made up of muscle and tissue and can be different sizes. Some can be the size of a pea, others can be the size of a melon. They're sometimes known as uterine myomas or leiomyomas. Fibroids are common. Around 1 in 3 people who menstruate develop them at some point in their life. They’re more common as you get older.
Symptoms
Many people don't know that they have fibroids because they don't have any symptoms. This is nothing to worry about. If your doctor thinks you might have fibroids, they'll usually refer you for an ultrasound scan to confirm the diagnosis. [ultrasound scan]
Why fibroids develop
The exact cause of fibroids is unknown. They’re linked to the hormones produced by the ovaries, oestrogen and progesterone. Fibroids usually develop and grow as long as the ovaries are producing these hormones. Fibroids may continue to grow during pregnancy. They tend to shrink when these hormone levels fall, such as after the menopause. [menopause]
Types of fibroids
There are different types of fibroid. The main types of fibroids are:
Treatment
Fibroids will often shrink after the menopause, as hormone levels in your body change. If you have fibroids, but you're not affected by any symptoms then you don't need treatment. However, if you do have symptoms, your doctor can recommend the right treatment for you. Treatment options include: [ibuprofen] [contraceptive pill] Your doctor will discuss these treatments with you and you can ask any questions that you might have. [questions that you might have.]
Fibroids and getting pregnant
If you're having difficulty getting pregnant, your doctor or specialist may suggest extra support or treatments that can help. Your doctor will discuss these with you and you can ask any questions that you might have. [questions that you might have.]
