An ectopic pregnancy is when a fertilised egg develops outside the womb. This usually happens in one of the fallopian tubes which lead from your ovaries to your womb. If an egg implants there, it can't develop into a baby. Ectopic pregnancy puts your health at risk too, and can be very serious if it isn't treated. About 1 in 100 pregnancies are an ectopic pregnancy.
Symptoms of an ectopic pregnancy
Symptoms usually start when you’re about 6 weeks pregnant and can include: You might also have: It’s important to get medical help quickly if you have any of these symptoms.
If you have an ectopic pregnancy
Unfortunately, it's not possible to save an ectopic pregnancy. It will need to be removed: To request a different language or format please email:
phs.otherformats@phs.scot [phs.otherformats@phs.scot]
