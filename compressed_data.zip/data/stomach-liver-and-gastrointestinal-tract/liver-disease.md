There are more than 100 different types of liver disease, which together affect at least 2 million people in the UK.
The liver
The liver is the second largest organ in the body. It works hard, performing hundreds of complex functions, including: [alcohol] Liver disease doesn't usually cause any obvious signs or symptoms until it's fairly advanced and the liver is damaged. At this stage, possible symptoms can include loss of appetite, weight loss and jaundice.
Types of liver disease
Listed below are some specific types of liver disease. The links provide more detailed information about each type. [Alcohol-related liver disease] [cirrhosis] [Non-alcoholic fatty liver disease] It’s important to note that all types of liver disease can cause cirrhosis (scarring of the liver), not just alcohol-related liver disease.
Significant health problem
In the UK, liver disease is on the increase. Three of the main causes of liver disease are: [obesity] [alcohol misuse] These causes of liver disease are all preventable so it's important to make sure: [read more about BMI] [alcohol units]
