What is sepsis?
Sepsis is a rare but serious complication of an infection. Without quick treatment, sepsis can lead to multiple organ failure and death.
What causes a sepsis infection?
The immune system usually keeps an infection limited to one place. This is called a localised infection. To do this, the body produces white blood cells. White blood cells travel to an infection site to destroy the germs causing the infection. This triggers tissue swelling, known as inflammation. This helps to fight the infection and prevent it from spreading. However, an infection can spread to other parts of the body if the immune system is weak or an infection is severe. Widespread inflammation can damage tissue and interfere with blood flow. When blood flow is interrupted, blood pressure can drop dangerously low. This stops oxygen from reaching the organs and tissues.
Sources of infection
Sepsis can be triggered by an infection in any part of the body. The most common sites of infection that lead to sepsis are the: However, sometimes the specific infection and source of sepsis can't be identified.
Tests to diagnose sepsis
Sepsis is often diagnosed by testing your: Other tests can help determine the type of infection, where it's located and which parts of the body have been affected. These include: [X-ray] [ultrasound scan] [computerised tomography (CT) scan]
Who’s at risk of sepsis?
Anyone can develop sepsis after an injury or minor infection. However, some people are more vulnerable, including people who: [HIV] [chemotherapy]
Recovering from sepsis
Some people make a full recovery from sepsis fairly quickly. The amount of time it takes to fully recover from sepsis varies depending on:
Long term effects of sepsis
Some people with sepsis will experience long-term physical and psychological problems. This is known as post-sepsis syndrome. Symptoms of post-sepsis syndrome include: Sepsis can cause a variety of symptoms.
Sepsis symptoms in children under 5
Sepsis symptoms in older children and adults
Early symptoms of sepsis may include:
Symptoms of severe sepsis or septic shock
In some cases, symptoms of more severe sepsis or septic shock (when your blood pressure drops to a dangerously low level) develop. [septic shock] These can include: Treatment for sepsis varies, depending on the: If you have the early signs of sepsis, you'll usually be referred to hospital. You'll then be given a diagnosis and treatment.
Emergency treatment
You'll need emergency treatment, or treatment in an intensive care unit (ICU), if: [septic shock] ICUs can support body functions like breathing that are affected by sepsis. This allows the medical staff to focus on treating the infection. Sepsis is treatable if it's identified and treated quickly. In most cases it leads to full recovery with no lasting problems.
Antibiotics
The main treatment for sepsis, severe sepsis or septic shock is antibiotics. These will be given directly into a vein (intravenously). [antibiotics] Ideally, antibiotic treatment should start within an hour of diagnosis. Intravenous antibiotics are usually replaced by tablets after 2 to 4 days. You may have to take them for 7 to 10 days or longer, depending on the severity of your condition. If sepsis is suspected, broad-spectrum antibiotics are given first. This is because there won't be time to wait until a specific type of infection has been identified. Broad-spectrum antibiotics work against a wide range of known infectious bacteria. They usually cure most common infections. Once a specific bacterium has been identified, a more focused antibiotic can be used.
Viral infections
If the sepsis is caused by a virus, antibiotics won't work. However, it would be too dangerous to delay treatment to find out the specific cause. This means antibiotics are usually given anyway. With a viral infection, you'll need to wait until your immune system starts to tackle it. However, antiviral medication may be given in some cases.
Intravenous fluids
If you have sepsis, your body needs more fluid to prevent dehydration and kidney failure. If you have severe sepsis or septic shock, you'll usually be given fluids intravenously for the first 24 to 48 hours. It's important that the doctors know how much urine your kidneys are making when you have sepsis. This helps them spot signs of kidney failure. If you're admitted with severe sepsis or septic shock, you'll usually be given a catheter. This is inserted into your bladder to monitor your urine output. [a catheter]
Oxygen
Your body's oxygen demand goes up if you have sepsis. If you're admitted to hospital with sepsis and the level of oxygen in your blood is low, you'll usually be given oxygen. This is given through a mask or tubes in your nostrils.
Treating the source of infection
If a source of the infection can be identified, like an abscess or infected wound, this will also need to be treated. For example, any pus may need to be drained away. In more serious cases, surgery may be needed to remove the infected tissue and repair any damage.
Increasing blood pressure
Medications called vasopressors are used if you have low blood pressure caused by sepsis. [low blood pressure] Vasopressors are normally given intravenously while you're in an ICU. Extra fluids may also be given intravenously to help increase blood pressure.
Other treatments
You may require additional treatments like: [corticosteroids] [a blood transfusion] [dialysis] These treatments are mostly used in ICUs.
