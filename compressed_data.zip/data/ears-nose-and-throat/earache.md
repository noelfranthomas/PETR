Earache is a common problem, particularly in children. It can be worrying, but it's usually only caused by a minor infection and will often get better in a few days without treatment. Earache can be a sharp, dull or burning ear pain that comes and goes or is constant. One or both ears may be affected.
When should I contact my GP?
It's not always necessary to see your GP if you or your child have earache. Your local pharmacist is always on hand to offer help and advice on how you can manage the problem. The pain will often improve in a few days and there are things you can do to help in the meantime.
Earache self-help guide
To assess your condition at home use our earache self-help guide.
Earache treatment from your pharmacy
If you have earache you can get advice and treatment directly from a pharmacy. Earache isn't usually serious and can be treated by a pharmacist. Your pharmacist may recommend that you contact your GP practice if required.
How can I treat earache at home?
You can ask your pharmacist about using over-the-counter painkillers such as paracetamol or ibuprofen to treat the pain. Children under the age of 16 should not take aspirin. [paracetamol] [ibuprofen] Placing a warm flannel against the affected ear may also help relieve the pain. Your pharmacist may also be able to recommend over-the-counter eardrops for your earache. But let them know your symptoms and ask for their advice first. Eardrops or olive oil drops should not be used if the eardrum has burst, and they will not help an ear infection. If you or your child has an ear infection, you should avoid putting objects in the ear, such as cotton buds, or getting the affected ear wet.
Common causes of earache
This information should not be used to self-diagnose your condition, but it may give you an idea as to what might be causing your earache. It does not include every possible cause, but outlines some of the most common reasons for earache.
Earache is a common problem, particularly in children. It can be worrying, but it's usually only caused by a minor infection and will often get better in a few days without treatment. Earache can be a sharp, dull or burning ear pain that comes and goes or is constant. One or both ears may be affected.
When should I contact my GP?
It's not always necessary to see your GP if you or your child have earache. Your local pharmacist is always on hand to offer help and advice on how you can manage the problem. The pain will often improve in a few days and there are things you can do to help in the meantime.
Earache self-help guide
To assess your condition at home use our earache self-help guide.
Earache treatment from your pharmacy
If you have earache you can get advice and treatment directly from a pharmacy. Earache isn't usually serious and can be treated by a pharmacist. Your pharmacist may recommend that you contact your GP practice if required.
How can I treat earache at home?
You can ask your pharmacist about using over-the-counter painkillers such as paracetamol or ibuprofen to treat the pain. Children under the age of 16 should not take aspirin. [paracetamol] [ibuprofen] Placing a warm flannel against the affected ear may also help relieve the pain. Your pharmacist may also be able to recommend over-the-counter eardrops for your earache. But let them know your symptoms and ask for their advice first. Eardrops or olive oil drops should not be used if the eardrum has burst, and they will not help an ear infection. If you or your child has an ear infection, you should avoid putting objects in the ear, such as cotton buds, or getting the affected ear wet.
Common causes of earache
This information should not be used to self-diagnose your condition, but it may give you an idea as to what might be causing your earache. It does not include every possible cause, but outlines some of the most common reasons for earache.
