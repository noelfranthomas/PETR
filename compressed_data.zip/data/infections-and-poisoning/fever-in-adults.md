Your normal body temperature is approximately 37°C. A fever is usually when your body temperature is 37.8°C or higher. You may feel warm, cold or shivery. You can find out if you have a fever by using a thermometer to take your temperature.
Fever in adults self-help guide
What causes a fever?
A fever is your body's natural response to many common illnesses such as: [flu] [tonsillitis] [kidney or urinary tract infections (UTIs)] Fever helps your body fight infections by stimulating your immune system (your body’s natural defence). By increasing your body’s temperature, a fever makes it harder for the bacteria and viruses that cause infections to survive.
When to get help
Most fevers will improve on their own in a few days. However, there are a number of things you can do to help the uncomfortable feelings associated with a fever.
Fever in children
Fever affects people of all ages, however it often affects babies and younger children in response to minor illnesses such as: Find out more about fever in children. [fever in children]
