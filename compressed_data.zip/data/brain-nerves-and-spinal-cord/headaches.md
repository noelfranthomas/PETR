Most headaches are not serious. In many cases, you can treat your headache at home. Complete our self-help guide to check your symptoms and find out what to do next.
How you can help your headache yourself
When to get professional advice
Your local pharmacy can provide:
Tension headaches
Tension headaches are the most common type of headache. They're what we think of as normal, 'everyday' headaches. They feel like a constant ache that affects both sides of the head, as though a tight band is stretched around it. Normally, tension headaches are not severe enough to prevent you doing everyday activities. They usually last for 30 minutes to several hours, but can last for several days. The exact cause is unclear, but tension headaches have been linked to things such as: [dehydration] You can usually treat tension headaches with painkillers such as paracetamol and ibuprofen. Lifestyle changes may also help, for example: [paracetamol] [ibuprofen] [reducing stress]
Migraines
Migraines are less common than tension headaches. They're usually felt as a severe, throbbing pain at the front or side of the head. Some people also have other symptoms, such as: Migraines can stop you carrying out your normal daily activities. They usually last at least a couple of hours. Some people find they need to stay in bed for days at a time. Most people can treat their migraines with over-the-counter medication from the pharmacist. If your migraines are severe, you may need to be prescribed stronger medication by your GP. This may be able to relieve and prevent your migraines. Read further information about migraines [migraines]
Cluster headaches
Cluster headaches are a rare type of headache. They occur in clusters for a month or two at a time around the same time of year.

Cluster headaches are excruciatingly painful. They cause intense pain around one eye, and often occur with other symptoms, such as a: Pharmacy medications don't usually ease the symptoms of a cluster headache. Your GP can prescribe specific treatments to ease the pain and help prevent further attacks.
Medication and painkiller headaches
Some headaches are a side effect of taking a particular medication. Frequent headaches can also be caused by taking too many painkillers. This is known as a painkiller or medication-overuse headache. A medication-overuse headache will usually get better within a few weeks once you stop taking the painkillers that are causing it. But, pain may get worse for a few days before it starts to improve.
Hormone headaches
Headaches in women are often caused by hormones, and many women notice a link with their periods. The combined contraceptive pill, the menopause and pregnancy are also potential triggers. [combined contraceptive pill] [menopause] You may be able to help reduce headaches associated with your menstrual cycle by: [reducing your stress levels]
Other causes of headaches
Headaches can also have a number of other causes, including: [head injury] [concussion] [cold] [flu] [sinusitis ] [sleep apnoea]
