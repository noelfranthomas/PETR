Trichomonas is a sexually transmitted infection (STI) caused by a small parasite. It infects the genitals and may also lead to infection in the:
How do you get trichomonas?
The main way to get trichomonas infection is by:
Symptoms of trichomonas
Almost half of all people with trichomonas infection will have no symptoms. If you do develop symptoms you may experience: Some women may also experience pain or discomfort during sex.
Testing for trichomonas
If you think you have trichomonas infection, make an appointment with your GP or local sexual health services. Testing for trichomonas may not be offered in all sexual health clinics. Testing is quick and straightforward. There are 2 main ways the sample can be collected: Most sexual health clinics can look at the sample straightaway under the microscope and see the parasite. In some clinics and at your GP, the swab needs to be sent away to a lab to make the diagnosis. The test is more accurate from vagina samples. It's less accurate from penile and urine samples.
Online appointment booking
You may be able to book an appointment for an STI test online using the online booking system. This varies for different NHS board areas.
Treating trichomonas
Antibiotics will get rid of the infection. You should avoid having sex until 1 week after you and your partner(s) have been treated. If your infection is untreated you may pass it onto other sexual partners.
Avoiding passing on trichomonas to a partner
It's advised that both you and your partner(s) are treated if you have the infection. You should avoid having sex until 1 week after you and your partner(s) treatment has finished.
Reducing the risk of trichomonas
The best way to prevent all sexually transmitted infections is to practice safe sex. This means using a condom for vaginal, oral or anal sex. If you have been diagnosed with trichomonas, it’s recommended you're tested for all STIs including: [chlamydia] [gonorrhoea] [syphilis]
